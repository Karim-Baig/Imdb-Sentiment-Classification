# -*- coding: utf-8 -*-
"""
"""

# Load data
import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.model_selection import cross_val_score
import matplotlib.pyplot as plt
import dask.dataframe as dd
from dask.distributed import Client

def load_data(filepath):
    
    print("Loading Data...")
    data = pd.read_csv(filepath, encoding = "ISO-8859-1")
    print("Done!")
    
    print("\n Data structure and details: \n")
    print("Shape" + str(data.shape))
    print(data.info())
    
    return data

# Plot Data
def data_plot(data, label):
    print("Distribution of emails:")
    sns.countplot(x = label, data = data)

	# Removing URLs
import re
def remove_urls(text):
    text = re.sub('https?://[A-Za-z0-9./]+','',text)
    text = re.sub("\\bhttp[^ ]*",'',text) #text starting with http
    text = re.sub("[^ ]*\\.com\\b",'',text) #text ending with .com
    text = re.sub("\\bwww\\.[^ ]*",'',text) #text starting with www.
    return text
    
# Apostrophes
from Apostrophes_Contractions import *
def expandContractions(text, c_re=c_re):
    def replace(match):
        return cList[match.group(0)]
    return c_re.sub(replace, text)

def remove_emoji(string):
    emoji_pattern = re.compile("["
                       u"\U0001F600-\U0001F64F"  # emoticons
                       u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                       u"\U0001F680-\U0001F6FF"  # transport & map symbols
                       u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                       u"\U00002702-\U000027B0"
                       u"\U000024C2-\U0001F251"
                       "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', string)

def slang_lookup(slang_filepath):
    my_file = open(slang_filepath, "r")
    slang_words_str = my_file.readlines()

    slang_words_map_dict = {}
    slang_words_list = []
    for line in slang_words_str:
        if line != "":
            sw = line.split(":")[0].strip()
            sw_expanded = line.split(":")[1].strip()
            slang_words_list.append(sw)
            slang_words_map_dict[sw] = sw_expanded
    slang_words_list = set(slang_words_list)
    my_file.close()
    return slang_words_list, slang_words_map_dict

def slang_words_conversion(text,slang_words_list,slang_words_map_dict):
    new_text = []
    for w in text.split():
        if w in slang_words_list:
            new_text.append(slang_words_map_dict[w])
        else:
            new_text.append(w)
    return " ".join(new_text)
	
def cross_validation(CV, models, X_train_vec, y_train):

    # compute accuracies for CV folds for each model
    cv_df = pd.DataFrame(index=range(CV * len(models)))
    entries = []

    for model in models:
      model_name = model.__class__.__name__
      accuracies = cross_val_score(model, X_train_vec, y_train, scoring='accuracy', cv=CV)
      for fold_idx, accuracy in enumerate(accuracies):
        entries.append((model_name, fold_idx, accuracy))

    cv_df = pd.DataFrame(entries, columns=['model_name', 'fold_idx', 'accuracy'])

    mean_accuracy = cv_df.groupby('model_name').accuracy.mean()
    std_accuracy = cv_df.groupby('model_name').accuracy.std()
    acc = pd.concat([mean_accuracy, std_accuracy], axis= 1, 
              ignore_index=True)
    acc.columns = ['Mean Accuracy', 'Standard deviation']

    sns.boxplot(x='model_name', y='accuracy', 
                data=cv_df, 
                color='lightblue', 
                showmeans=True)
    plt.title("MEAN ACCURACY (cv = 5)\n", size=14);

    return acc
	
def add_text_features(data, X_data_vec, vectorizer):

    df_vec = pd.DataFrame(X_data_vec.toarray(), \
                        columns = vectorizer.get_feature_names())
    df_vec = pd.concat([data,df_vec],axis=1).fillna(0)
    df_vec = df_vec.\
                 drop(columns=['Email_identifier',\
                               'Body',\
                               'Subject',\
                               'Attachment_content',\
                               'Sender_address',\
                               'Recipient_address',\
                               'Lexicon_category',\
                               'Lexicon_ruleID',\
                               'Severity',\
                               'Number_of_emails',\
                               'Label',\
                               'Email_cleaned',\
							   'Email'])
    vec = df_vec.to_numpy()
    return vec
