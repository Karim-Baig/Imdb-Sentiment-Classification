# -*- coding: utf-8 -*-
"""

"""

# =============================================================================
# Consolidated Email Classification Code
# =============================================================================

# Keep all the files in one folder, and specify the folder path here
path = r"____"

# Specify filenames
file_email = "Email.csv"
file_slang = "Slang_Lookup.txt"

# Do you wish to include text based features - y/n
# include_text_features = "y" # Feature not working!!

# =============================================================================
# Importing relevant libraries and modules
# =============================================================================
print("\n")
print("Step 1: Importing libraries ------------------------------------")
print("Please wait...")

# Changing the working directory to the path mentioned above
import os
os.chdir(path)
del path

import time
start = time.time() #to calculate the time to run the program

# to import user defined modules
import sys
if os.getcwd() not in sys.path:
    sys.path.append(os.getcwd())

# user defined modules
from Functions import *
# from LoadData import *

# import libraries
import gc
import pandas as pd
import string
import spacy
nlp = spacy.load("en") #Load english language
from bs4 import BeautifulSoup #only for html tags
from autocorrect import Speller #Spell check
import numpy as np

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn import metrics

from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC

import matplotlib.pyplot as plt
import seaborn as sns # used for plot interactive graph. 

#Utilizing Dask for parralel processing#
#Inorder to install go to cmd prompt > python -m pip install "dask[complete]" 
import dask.dataframe as dd
from dask.distributed import Client

t2 = time.time()
print("Done!")
print("Time taken: ", t2-start)

# =============================================================================
# Load and visualize data
# =============================================================================
print("\n")
print("Step 2: Loading data -------------------------------------------")
print("Please wait...")

# load data
df = load_data(file_email)
# convert the pandas dataframe to dask dataframe 
df = df.from_pandas(train_data, npartitions=4)

# concatenate body, subject, and attachment data to get a column - Email
df["Email"] = df["Body"].fillna(" ").astype(str) + " "+ \
              df["Subject"].fillna(" ").astype(str) + " "+ \
              df["Attachment_content"].fillna(" ").astype(str)

# plot data  
data_plot(df, "Label")

# remove extra variables
del file_email
gc.collect()

t3 = time.time()
print("Done!")
print("Time taken: ", t3-t2)
del t2
gc.collect()

# =============================================================================
# Data Cleaning
# =============================================================================
print("\n")
print("Step 3: Data Cleaning ------------------------------------------")
print("Please wait...")

# import slang file
slang_words_list, slang_words_map_dict = slang_lookup(file_slang)
check = Speller(lang='en')

def data_clean(text):
    
    #HTML decoding
    text = BeautifulSoup(text, 'lxml').get_text()

    #Removing URLs            
    text = remove_urls(text)

    #Splitting attached words
    # text = " ".join(re.findall("[a-zA-Z][^A-Z]*", text)) #only handles cases such as DayIsAwesome and not dayisawesome
    
    #Case Check
    text = text.lower() #lower case
    
    #Slangs
    text = slang_words_conversion(text, slang_words_list, slang_words_map_dict).lower()
    
    #Apostrophes
    text = expandContractions(text) #replace with english full word

    #Removing Special characters
    #Emoticons
    text = remove_emoji(text)

    #Anything other than alphabets
    text = re.sub("[^a-zA-Z\s]", '', text)

    #Remove multiple whitespaces
    text = re.sub(' +',' ', text)

    #Standardization
    text = re.sub(r'(\w)\1+', r'\1\1', text) #Removes multiple occurences of characters - Cooooool to Cool

    #Spell Check
    text = check(text)
  
    #Stop words
    # doc = nlp(text)
    # text = " ".join([token.text for token in doc if not token.is_stop])

    #Lemmatization 
    doc = nlp(text)    
    text = " ".join([token.lemma_ for token in doc]).strip()

    return text

df['Email_cleaned'] = df['Email'].apply(lambda x: data_clean(x), meta=('sentence')).compute(scheduler='processes')
df=df.compute(num_workers=4)
del slang_words_list, slang_words_map_dict, file_slang
del c_re, cList

gc.collect()

t4 = time.time()
print("Done!")
print("Time taken: ", t4-t3)
del t3
gc.collect()

df.to_csv("Email_Cleaned.csv",index = False)


# =============================================================================
# Feature extraction
# =============================================================================

print("\n")
print("Step 4: Feature extraction -------------------------------------")
print("Please wait...")

# Creating Text-NLP based features ----------------------------------------------
print("Creating text/nlp based features...")

# word count
print("Word count")
df['word_count'] = df['Email'].apply(lambda x: len(x.split()), meta=('int64')).compute(scheduler='processes')

# character count
print("Character count")
df['char_count'] = df['Email'].apply(len, meta=('int64')).compute(scheduler='processes')

# word density
print("Average word density")
df['word_density'] = df['char_count']/df['word_count']

# stop word count
print("Number of stop words")
spacy_stopwords = list(nlp.Defaults.stop_words)
df['stopword_count'] = df['Email'].\
                        apply(lambda x: len([wrd for wrd in x.split() \
                                        if wrd.lower() in spacy_stopwords]), meta=('int64')).compute(scheduler='processes')
# del spacy_stopwords

# punctuation count
print("Number of punctuations")
punctuation = string.punctuation
df['punctuation_count'] = df['Email'].\
                          apply(lambda x: len("".join(_ for _ in x \
                                                      if _ in punctuation)))
del punctuation

# upper case word count
print("Number of words in BLOCK letters")
df['CAPS_word_count'] = df['Email'].\
                        apply(lambda x: len([wrd for wrd in x.split() \
                                              if wrd.isupper()]), meta=('int64')).compute(scheduler='processes')

# noun, verb, adjective, adverb, pronoun count
# this patch takes the maximum time!!!!!!!!!!!!!!!!! 
print("Number of words under various POS tags")
pos_dic = {
    'noun' : ['NN','NNS','NNP','NNPS','NOUN','PROPN'],
    'pron' : ['PRP','PRP$','WP','WP$','PRON'],
    'verb' : ['VB','VBD','VBG','VBN','VBP','VBZ','AUX','VERB'],
    'adj' :  ['JJ','JJR','JJS','ADJ'],
    'adv' : ['RB','RBR','RBS','WRB','ADV'],
    'det' : ['DET']
}

def pos_check(x,flag):
    doc = nlp(x)
    cnt = 0
    try:
        for token in doc:
            pos = token.pos_
            if pos in pos_dic[flag]:
                cnt += 1
    except:
        pass
    return cnt

df['noun_count'] = df['Email'].apply(lambda x: pos_check(x, 'noun')).compute(scheduler='processes')
df['verb_count'] = df['Email'].apply(lambda x: pos_check(x, 'verb')).compute(scheduler='processes')
df['adj_count'] = df['Email'].apply(lambda x: pos_check(x, 'adj')).compute(scheduler='processes')
df['adv_count'] = df['Email'].apply(lambda x: pos_check(x, 'adv')).compute(scheduler='processes')
df['pron_count'] = df['Email'].apply(lambda x: pos_check(x, 'pron')).compute(scheduler='processes')
df['det_count'] = df['Email'].apply(lambda x: pos_check(x, 'det')).compute(scheduler='processes')

df=df.compute(num_workers=4)

del pos_dic
gc.collect()

t5 = time.time()
print("Done!")
print("Time taken: ", t5-t4)
del t4
gc.collect()
del spacy_stopwords



# Split data into train and test ----------------------------------------------
train, test = train_test_split(df, test_size=0.25, random_state = 0)

# Text-NLP based vectorization ------------------------------------------------
# if using text-nlp based features  then use the following Code:
# and comment out other vectorizers
drop_cols = ['Email_identifier',\
             'Body',\
             'Subject',\
             'Attachment_content',\
             'Sender_address',\
             'Recipient_address',\
             'Lexicon_category',\
             'Lexicon_ruleID',\
             'Severity',\
             'Number_of_emails',\
             'Label',\
             'Email_cleaned',\
			 'Email']
X_train_vec = train.drop(columns=drop_cols,axis =1)
y_train = train['Label']

X_test_vec = test.drop(columns=drop_cols,axis =1)
y_test = test['Label']

# TF - IDF vectorization ------------------------------------------------
# if using tf-idf based features then use the following Code:
# and comment out other vectorizers

X_train = train['Email_cleaned']
y_train = train['Label']

X_test = test['Email_cleaned']
y_test = test['Label']

print("Training Set: ", X_train.shape)
print("Test Set: ", X_test.shape)    

vectorizer = TfidfVectorizer(analyzer='word', \
                          ngram_range=(1, 1), \
                          stop_words='english', \
                          strip_accents='unicode',\
                          dtype=np.float32)

# Vectorize the text using the vectorizer defined
X_train_vec = vectorizer.fit_transform(X_train)   
X_test_vec = vectorizer.transform(X_test)   

# if include_text_features == 'y':
#     X_train_vec = add_text_features(train, X_train_vec, vectorizer)
#     X_test_vec = add_text_features(test, X_test_vec, vectorizer)
    
    # Sorting features by tf-idf
tfidf = dict(zip(vectorizer.get_feature_names(), vectorizer.idf_))
tfidf = pd.DataFrame(columns=['word_tfidf']).from_dict(dict(tfidf), orient='index')
tfidf.columns = ['word_tfidf']
tfidf = tfidf.sort_values(by=['word_tfidf'], ascending=False)

# Bag of Words vectorization ------------------------------------------------
# if using bag of words i.e. count based features then use the 
# following Code and comment out other vectorizers

X_train = train['Email_cleaned']
y_train = train['Label']

X_test = test['Email_cleaned']
y_test = test['Label']

print("Training Set: ", X_train.shape)
print("Test Set: ", X_test.shape)    

vectorizer = CountVectorizer(analyzer='word', \
                          ngram_range=(1, 1), \
                          stop_words='english', \
                          strip_accents='unicode')
    
# Vectorize the text using the vectorizer defined
X_train_vec = vectorizer.fit_transform(X_train)   
X_test_vec = vectorizer.transform(X_test) 

# if include_text_features == 'y':
#     X_train_vec = add_text_features(train, X_train_vec)
#     X_test_vec = add_text_features(test, X_test_vec)


# vectorizer - word2vec -------------------------------------------------------    
# if using word2vec based features then use the 
# following Code and comment out other vectorizers

# Need to have globe embeddings to run the below code!!
"""
from word2vec import *
X_train = train['Email_cleaned']
y_train = train['Label']

X_test = test['Email_cleaned']
y_test = test['Label']

print("Training Set: ", X_train.shape)
print("Test Set: ", X_test.shape)    

#Training a word2vec model - optional
model_self_cbow, model_self_skipgram = selftrained_word2vec(X_train)

# Create doc vectors using the word2vec model
def create_features_using_word2vec(X, model):
    docs_vectors = pd.DataFrame()
    for doc in X: # looping through each document and cleaning it
        temp = pd.DataFrame()  # creating a temporary dataframe(store value for 1st doc & for 2nd doc remove the details of 1st & proced through 2nd and so on..)
        for word in doc.split(' '): # looping through each word of a single document and spliting through space
            try:
                word_vec = model[word] # if word is present in embeddings(goole provides weights associate with words(300)) then proceed
                temp = temp.append(pd.Series(word_vec), ignore_index = True) # if word is present then append it to temporary dataframe
            except:
                pass
        doc_vector = temp.mean() # take the average of each column(w0, w1, w2,........w300)
        docs_vectors = docs_vectors.append(doc_vector, ignore_index = True) # append each document value to the final dataframe
    return docs_vectors

# Using pre-trained model i.e. GloVe to create vectors
X_train_vec = create_features_using_word2vec(X_train[:20], model_glove)   
X_test_vec = create_features_using_word2vec(X_test[:20], model_glove)

# Using slef-trained model to create vectors
# 1. CBOW
X_train_vec = create_features_using_word2vec(X_train[:20], model_self_cbow)   
X_test_vec = create_features_using_word2vec(X_test[:20], model_self_cbow)
# 2. Skip gram
X_train_vec = create_features_using_word2vec(X_train[:20], model_self_skipgram)   
X_test_vec = create_features_using_word2vec(X_test[:20], model_self_skipgram)
"""
# =============================================================================
# Modelling
# =============================================================================

# Model comparison ------------------------------------------------------------
# Define models to try for comparison
models = [
    RandomForestClassifier(n_estimators=100, max_depth=5, random_state=0),
    LinearSVC(),
    MultinomialNB(),
    LogisticRegression(random_state=0),
]

# Cross-validation to compare models
CV = 5
accuracies = cross_validation(CV, models, X_train_vec, y_train[:20])

# Define the final model and make predictions ---------------------------------
model = MultinomialNB()
model.fit(X_train_vec, y_train)
y_pred = model.predict(X_test_vec)

print('\t\t\t\tCLASSIFICATIION METRICS\n')
print(metrics.classification_report(y_test, y_pred))

print('\t\t\t\tCONFUSION MATRIX\n')
conf_mat = confusion_matrix(y_test, y_pred)
fig, ax = plt.subplots(figsize=(8,8))
sns.heatmap(conf_mat, annot=True, cmap="Blues", fmt='d')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.title("CONFUSION MATRIX \n", size=16);
del fig, ax
    

end = time.time()
print("Done!")
print("Time taken: ", end-t5)
del t5
print("Total time to run the program: ", end-start)
gc.collect()

# =============================================================================
# References
# =============================================================================

# https://www.kaggle.com/selener/multi-class-text-classification-tfidf
# https://www.analyticsvidhya.com/blog/2017/09/pseudo-labelling-semi-supervised-learning-technique/











