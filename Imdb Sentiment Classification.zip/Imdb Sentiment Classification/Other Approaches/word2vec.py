# -*- coding: utf-8 -*-
"""
"""

# =============================================================================
# Getting the word2vec model
# =============================================================================
import os

import warnings   
warnings.filterwarnings(action = 'ignore') 
import sys
import gensim
import numpy as np
import gc
import pandas as pd
import nltk
from gensim.models import KeyedVectors
from gensim.scripts.glove2word2vec import glove2word2vec
from nltk.tokenize import sent_tokenize, word_tokenize   
from gensim.models import Word2Vec        

# 1. GLOVE --------------------------------------------------------------------
# We are using the pre-trained model called GloVe (Global Vectors) for
# word representation.
# Download the same here: https://nlp.stanford.edu/projects/glove/
# and save the embeddings in the current directory
# Useful article for using KeyedVectors https://radimrehurek.com/gensim/models/keyedvectors.html

# Step1 - Convert the downloaded .txt embeddings to a word2vec file
glove_input_file = 'glove.42B.300d.txt'
word2vec_output_file = 'glove.42B.300d.txt.word2vec'

if os.path.isfile("GloVe.bin")==False: 
    glove2word2vec(glove_input_file, word2vec_output_file)

    # load the Stanford GloVe model
    model_glove = KeyedVectors.load_word2vec_format(word2vec_output_file, binary=False)
    
    # save the model to a .bin file for later use
    model_glove.save("GloVe.bin")

else: 
    # load the already saved model
    model_glove = KeyedVectors.load('GloVe.bin')

del glove_input_file, word2vec_output_file

  
# 2. Training a Word2Vec model ------------------------------------------------
def selftrained_word2vec(X_train):# iterate through each sentence in the file 
    data = [] 
    
    for i in X_train.iteritems(): 
        temp = [] 
          
        # tokenize the sentence into words 
        for j in word_tokenize(i[1]): 
            temp.append(j.lower()) 
      
        data.append(temp)
    
    # Create CBOW model 
    model_self_cbow = gensim.models.Word2Vec(data, min_count = 1,  
                                  size = 100, window = 2) 
     
    # Create Skip Gram model 
    model_self_skipgram = gensim.models.Word2Vec(data, min_count = 1, size = 100, 
                                                 window = 2, sg = 1)
    return model_self_cbow, model_self_skipgram
    
# 2. SPACY --------------------------------------------------------------------
# The library comes with the pre-trained embeddings and we can use the same.
# We would need to download 'en_core_web_lg' that contains all the big
# models for english language
# Use command 'python -m spacy download en_core_web_lg'
# For details refer https://spacy.io/models/en#en_core_web_lg
"""
import spacy
        
# Load the spacy model that you have installed
nlp = spacy.load('en_core_web_lg')

# process a sentence using the model
doc = nlp("This is some text that I am processing with Spacy")

# It's that simple - all of the vectors and words are assigned after this point
# Get the vector for 'text':
doc[3].vector

# Get the mean vector for the entire sentence (useful for sentence classification etc.)
doc.vector

for token1 in doc:
    for token2 in doc:
        print(token1.text, token2.text, token1.similarity(token2))
"""

