# -*- coding: utf-8 -*-
"""
"""


"""
Created on Sat Aug 15 15:13:14 2020

@author: Karim
"""
import tensorflow as tf
from tensorflow.python.keras.callbacks import ReduceLROnPlateau

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Activation, Dropout
from numpy.random import seed 
from tensorflow import set_random_seed
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier 
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn import metrics
import pandas as pd
import numpy as np
import gc
# packages for plotting 
import matplotlib.pyplot as plt 
from matplotlib.pyplot import rcParams
#%matplotlib inline
import seaborn as sns
rcParams['figure.figsize']= 10,8
sns.set(style='whitegrid', palette='muted', rc={'figure.figsize':(15,10)})
char_wb="char_wb"
train_data=pd.read_csv("D:\\train_imdb_cleaned.csv")
vectorizer = TfidfVectorizer(analyzer='char_wb', \
                              ngram_range=(2, 2), \
                              stop_words='english', \
                              strip_accents='unicode',\
                              dtype=np.float32)
X = train_data['Sentence_Cleaned']
X_vec = vectorizer.fit_transform(X)
del X

df_text_vec = pd.DataFrame(X_vec.toarray(), \
                        columns = vectorizer.get_feature_names())
df_text_vec.shape
del X_vec
df_text_vec = pd.concat([train_data,df_text_vec],axis=1)
df_text_vec = df_text_vec.drop(columns=['Unnamed: 0','sentence','Sentence_Cleaned', 'sentiment'])

X_vec=df_text_vec.to_numpy()

y = df_text_vec['polarity']
df_text_vec=df_text_vec.drop(columns=['polarity'])

X_train, X_test, y_train, y_test = train_test_split(X_vec, y, 
                                                    test_size=0.25,
                                                    random_state = 0)

def create_model_2(lyrs=[8],act='linear', opt='Adagrad', dr=0.0, learn_rate=0.01, momentum=0, init_mode='uniform'):
    seed(42)
    set_random_seed(42)
    model=Sequential()
    model.add(Dense(lyrs[0], input_dim=X_train.shape[1],activation=act))
    for i in range(1,len(lyrs)):
        model.add(Dense(lyrs[i], kernel_initializer=init_mode,activation=act))
    model.add(Dropout(dr))
    model.add(Dense(1, kernel_initializer=init_mode,activation='sigmoid'))
    optimizer = SGD(lr=learn_rate, momentum=momentum)
    model.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])
    return model

model = KerasClassifier(build_fn=create_model_2, epochs=1000, batch_size=32, verbose=0)
#drops = [0.0,0.01,0.05,0.1,0.2,0.5]
layers = [[8],[10],[10,5],[12,6],[12,8,4],[1024,512,256,64,8]]
#activation = ['softmax', 'softplus', 'softsign', 'relu', 'tanh', 'sigmoid', 'hard_sigmoid', 'linear']

activation = ['softmax', 'relu', 'tanh', 'sigmoid', 'linear']
#learn_rate = [0.001, 0.01, 0.1, 0.2, 0.3]
#momentum = [0.0,0.05,0.1,0.2, 0.4, 0.6, 0.8, 0.9]
#init_mode = ['uniform', 'lecun_uniform', 'normal', 'zero', 'glorot_normal', 'glorot_uniform', 'he_normal', 'he_uniform']
####-- add this = param_grid = dict(init_mode=init_mode)
#param_grid=dict(dr=drops, lyrs=layers, act= activation,learn_rate=learn_rate, momentum=momentum,init_mode=init_mode)
param_grid=dict(lyrs=layers, act= activation)
gc.collect()
#n_jobs=2 as I am using CPU on local machine 
grid = GridSearchCV(estimator = model, param_grid = param_grid , verbose=2,n_jobs=1)
grid_result=grid.fit(X_train,y_train)

print("Best: %f using %s" % (grid_result.best_score_,grid_result.best_params_))

model = create_model_2(lyrs=[10,5], dr=0.0, act='relu',momentum=0.01, learn_rate=0.05)
print(model.summary())



reduce_lr=ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=10, min_lr=0.001)

training = model.fit(X_train,y_train,batch_size=32,epochs = 2000, validation_data=[X_test,y_test],callbacks=[reduce_lr],verbose=1)
# Optimize on the parameters on Neural Network 
# Either Step-wise or all at once basis your computers hardware 


scores= model.evaluate(X_train,y_train)
print("\n%s: %.2f%%" %(model.metrics_names[1], scores[1]*100))
