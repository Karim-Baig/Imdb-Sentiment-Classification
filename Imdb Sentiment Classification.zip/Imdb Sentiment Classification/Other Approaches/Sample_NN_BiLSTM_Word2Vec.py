# -*- coding: utf-8 -*-
"""
"""

# assumption is to load the CSV file 
# read the appended column 
# this column has been made post data cleaning steps 

import gzip
import numpy as np
import os
import pandas as pd
import pickle
import requests
import time
import gensim, logging
os.environ['KERAS_BACKEND']='cntk'
from keras.preprocessing import sequence
from keras.preprocessing.text import Tokenizer, text_to_word_sequence
from keras.models import Sequential, load_model
from keras import regularizers
from keras.optimizers import SGD
from keras.layers import Dense, Dropout, Embedding, LSTM, Bidirectional
from keras.callbacks import History, CSVLogger
from keras.utils import to_categorical
import nltk 

nltk.download('punkt')

MAX_DOC_LEN = 300
VOCAB_SIZE = 6000
EMBEDDING_DIM = 100
TEXT_COL = 'Sentence_Cleaned' # column name
LABEL_COL = 'polarity' # target name 

train_data=pd.read_csv("D:\\train_imdb_cleaned.csv")
test_data= pd.read_csv("D:\\train_imdb_cleaned.csv")

tok = Tokenizer(num_words=VOCAB_SIZE, lower=True, split=" ")
tok.fit_on_texts(train_data[TEXT_COL])
train_seq = tok.texts_to_sequences(train_data[TEXT_COL])
train_seq = sequence.pad_sequences(train_seq, maxlen=MAX_DOC_LEN)
test_seq = tok.texts_to_sequences(test_data[TEXT_COL])
test_seq = sequence.pad_sequences(test_seq, maxlen=MAX_DOC_LEN)

labels = to_categorical(np.asarray(train_data[LABEL_COL]))
labels = labels.astype('float32')

print('Number of reviews by class in training set')
print(labels.sum(axis=0))
n_classes = labels.shape[1]

sent_lst = []

for doc in train_data[TEXT_COL]:
    sentences = nltk.tokenize.sent_tokenize(doc)
    for sent in sentences:
        word_lst = [w for w in nltk.tokenize.word_tokenize(sent) if w.isalnum()]
        sent_lst.append(word_lst)

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)
# use skip-gram
word2vec_model = gensim.models.Word2Vec(sentences=sent_lst, min_count=6, size=EMBEDDING_DIM, sg=1, workers=os.cpu_count())

embeddings_index = {}

for word in word2vec_model.wv.vocab:
    coefs = np.asarray(word2vec_model.wv[word], dtype='float32')
    embeddings_index[word] = coefs

print('Total %s word vectors.' % len(embeddings_index))

# Initial embedding
embedding_matrix = np.zeros((VOCAB_SIZE, EMBEDDING_DIM))

for word, i in tok.word_index.items():
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None and i < VOCAB_SIZE:
        embedding_matrix[i] = embedding_vector

BATCH_SIZE = 50
NUM_EPOCHS = 5
LSTM_DIM = 100
OPTIMIZER = SGD(lr=0.01, nesterov=True)

def lstm_create_train(reg_param):
    l2_reg = regularizers.l2(reg_param)

    # model init
    embedding_layer = Embedding(VOCAB_SIZE,
                                EMBEDDING_DIM,
                                input_length=MAX_DOC_LEN,
                                trainable=True,
                                mask_zero=False,
                                embeddings_regularizer=l2_reg,
                                weights=[embedding_matrix])

    lstm_layer = LSTM(units=LSTM_DIM, kernel_regularizer=l2_reg)
    dense_layer = Dense(n_classes, activation='softmax', kernel_regularizer=l2_reg)

    model = Sequential()
    model.add(embedding_layer)
    model.add(Bidirectional(lstm_layer))
    model.add(dense_layer)

    model.compile(loss='categorical_crossentropy',
                  optimizer=OPTIMIZER,
                  metrics=['acc'])

    fname = "lstm_comp"
    history = History()
    csv_logger = CSVLogger('./{0}_{1}.log'.format(fname, reg_param),
                           separator=',',
                           append=True)

    t1 = time.time()
    # model fit
    model.fit(train_seq,
              labels.astype('float32'),
              batch_size=BATCH_SIZE,
              epochs=NUM_EPOCHS,
              callbacks=[history, csv_logger],
              verbose=2)
    t2 = time.time()

    # save model
    model.save('./{0}_{1}_model.h5'.format(fname, reg_param))
    np.savetxt('./{0}_{1}_time.txt'.format(fname, reg_param), 
               [reg_param, (t2-t1) / 3600])
    with open('./{0}_{1}_history.txt'.format(fname, reg_param), "w") as res_file:
        res_file.write(str(history.history))
        
lstm_create_train(1e-7)

from sklearn.metrics import accuracy_score, roc_auc_score, roc_curve
model = load_model('./lstm_food_{0}_model.h5'.format(1e-7))
preds = model.predict(test_seq, verbose=0)
print(("Accuracy = {0} \t AUC = {1}".format(accuracy_score(test_data[LABEL_COL], preds.argmax(axis=1)), 
       roc_auc_score(test_data[LABEL_COL], preds[:, 1]))))

%pylab inline
fpr, tpr, _ = roc_curve(test_data[LABEL_COL], preds[:, 1])
plot(fpr, tpr)
xlabel('FPR')
ylabel('TPR')